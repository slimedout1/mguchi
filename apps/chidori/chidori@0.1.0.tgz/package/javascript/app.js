'use strict';
/**
 * Chidori - a rev counter with two dashboard themes.
 *
 *   - Default: 270-degree rev arc (gap at the bottom, 1 at lower-left, N at lower-right), the
 *     gear in the middle of the dial, warm-up panel, tyres and a readout grid
 *   - Cam Girl: a pink streaming-overlay layout whose cam box plays a GIF scrubbed by rpm.
 *     The GIF belongs to this theme: it is always on here and never shown in Default.
 *     A theme that wants a GIF names its pack in THEMES (gif_<name>.pack in this folder).
 *
 * The GIF is drawn as baked mosaic LAYERS (merged runs of coloured rects), so the app keeps
 * working in native/chrome mode - which keeps the real BMW bar, tabs, clock and settings.
 * (Pixel images via setImage()/image() need "chrome": false and would lose all of that.)
 */
const fs = require('fs');
const path = require('path');
const mgu = require('./kit/mgu');
const G = require('./kit/gauges');
const Car = require('./kit/car');
const { withAlpha } = require('./kit/canvas');
const { makeLayer, dropLayer } = require('./kit/record');

const W = 1600, MPH = 1.609344, RAD = Math.PI / 180;
const GUT = 16, VGUT = 8, PANEL_W = 346, RIGHT_W = 420;
const A_LO = -135, A_SWEEP = 270;
const GIF_CELLS = 300;                             // GIF mosaic: cells across the box (higher = smoother but slower startup)
const SOLID = { red: '#e4002b', amber: '#f5a623', green: '#2fd27a', blue: '#2fb6ff', white: '#ffffff' };
const BLUE = '#2fb6ff', GREEN = '#2fd27a';

function loadPack(file) {
    const b = fs.readFileSync(file);
    if (b.length < 13 || b.toString('ascii', 0, 4) !== 'MGIF') throw new Error('not a MGIF pack');
    const w = b.readUInt16LE(5), h = b.readUInt16LE(7), n = b.readUInt16LE(9), fps = b.readUInt16LE(11) || 12;
    const size = w * h * 4, frames = [];
    for (let i = 0; i < n; i++) frames.push(b.slice(13 + i * size, 13 + (i + 1) * size));
    return { w, h, n, fps, frames };
}
function discoverPacks(dir) {
    const out = {};
    try { for (const f of fs.readdirSync(dir)) if (f.indexOf('gif_') === 0 && f.slice(-5) === '.pack') out[f.slice(4, -5)] = path.join(dir, f); } catch (e) { /* none */ }
    return out;
}

/**
 * One pack frame -> a cached layer of coloured rectangles, Dw x Dh. The source is cover-fitted
 * (cropped to fill, no distortion). Each cell is the average of the source pixels under it,
 * colours are cut to 5 bits per channel, and neighbouring cells of the same colour on a row are
 * ONE rectangle. Against a rect per cell this is roughly 4x fewer commands per frame.
 */
function bakeFrame(pk, f, Dw, Dh) {
    const buf = pk.frames[f], sw = pk.w, sh = pk.h;
    const Nw = GIF_CELLS, Nh = Math.max(1, Math.round(Dh / (Dw / Nw))), cw = Dw / Nw, ch = Dh / Nh;
    const scale = Math.max(Dw / sw, Dh / sh), vw = Dw / scale, vh = Dh / scale, ox = (sw - vw) / 2, oy = (sh - vh) / 2;
    return makeLayer(Dw, Dh, (c) => {
        for (let gy = 0; gy < Nh; gy++) {
            const y0 = Math.max(0, Math.floor(oy + gy / Nh * vh)), y1 = Math.min(sh, Math.max(y0 + 1, Math.ceil(oy + (gy + 1) / Nh * vh)));
            let runX = 0, runKey = -1, runCol = null;
            const flush = (gx) => { if (runKey >= 0) c.fillRect(runX * cw, gy * ch, (gx - runX) * cw + 1.2, ch + 1.2, runCol); };
            for (let gx = 0; gx < Nw; gx++) {
                const x0 = Math.max(0, Math.floor(ox + gx / Nw * vw)), x1 = Math.min(sw, Math.max(x0 + 1, Math.ceil(ox + (gx + 1) / Nw * vw)));
                let r = 0, g = 0, b = 0, a = 0, n = 0;
                for (let y = y0; y < y1; y++) { let i = (y * sw + x0) * 4; for (let x = x0; x < x1; x++) { r += buf[i]; g += buf[i + 1]; b += buf[i + 2]; a += buf[i + 3]; n++; i += 4; } }
                let key = -1, R = 0, G5 = 0, B = 0;
                if (n && a / n >= 28) { R = (r / n) >> 3; G5 = (g / n) >> 3; B = (b / n) >> 3; key = (R << 10) | (G5 << 5) | B; }
                if (key !== runKey) {
                    flush(gx);
                    runX = gx; runKey = key;
                    runCol = key >= 0 ? [(R << 3) | (R >> 2), (G5 << 3) | (G5 >> 2), (B << 3) | (B >> 2), 255] : null;
                }
            }
            flush(Nw);
        }
    }, 1);
}

mgu.run({
    async start(ctx) {
        const { ui, settings, log } = ctx;

        const PROFILES = { diesel: { redline: 5000 }, petrol: { redline: 7000 } };
        const ETYPE = { 4: 'petrol', 5: 'petrol', 6: 'diesel', 7: 'diesel', 8: 'petrol', 9: 'petrol',
            BENZIN_DIREKTEINSPRITZUNG: 'petrol', BENZIN_KONVENTIONELL: 'petrol',
            DIESEL_DIREKTEINSPRITZUNG: 'diesel', DIESEL_KONVENTIONELL: 'diesel', ELEKTROMOTOR: 'petrol', HYBRIDMOTOR: 'petrol' };
        let engineType = null;
        const profile = () => { const s = settings.get('engine'); return s === 'diesel' || s === 'petrol' ? s : engineType || 'petrol'; };
        const baseRed = () => { const r = settings.get('redline'); return r > 0 ? r : PROFILES[profile()].redline; };
        const scaleMax = () => { const s = settings.get('rpmScale'); return s > 0 ? s : Math.ceil((baseRed() + 800) / 1000) * 1000; };
        const redline = () => Math.min(baseRed(), scaleMax());
        const coldRev = () => (profile() === 'diesel' ? 3000 : 3500);
        const feedEngineType = (v) => { const t = ETYPE[v && v.typeEngine]; if (t) engineType = t; };

        const car = new Car(ctx, ['rpm', 'speed', 'temps', 'gear', 'torque'], {
            'de.bmw.infotainment.vehicle.Vehicle2': { statusVehiclePartType: feedEngineType },
        });

        const revColour = (frac) => {
            const m = settings.get('revColour');
            if (m === 'tri_agr') return frac < 0.55 ? SOLID.green : frac < 0.82 ? SOLID.amber : SOLID.red;
            if (m === 'tri_m') return frac < 0.45 ? '#4aa8ff' : frac < 0.80 ? '#1b4bd8' : SOLID.red;
            return SOLID[settings.get('revSolidColour')] || SOLID.red;
        };

        /* ---------- themes and their GIF ----------
         * A theme names the GIF pack it plays (gif_<name>.pack in this folder), or null for none.
         * The pack is loaded only while its theme is on and freed when you leave it. To add a
         * theme: add it here, add it to the dashTheme options in app.json, and draw it below. */
        const THEMES = { default: { gif: null }, camgirl: { gif: 'camgirl' } };
        const themeId = () => (THEMES[settings.get('dashTheme')] ? settings.get('dashTheme') : 'default');

        /* ---------- GIF: baked mosaic layers, one per frame, scrubbed by rpm ---------- */
        const packs = discoverPacks(__dirname);
        let pk = null, layers = null, layerKey = '', packName = null;
        const freeLayers = () => { if (layers) layers.forEach((L) => L && dropLayer(L)); layers = null; layerKey = ''; };
        const openPack = (name) => {
            if (name === packName) return;
            packName = name; freeLayers(); pk = null;
            if (name && packs[name]) {
                try {
                    pk = loadPack(packs[name]);
                    log.info('gif ' + name + ': ' + pk.n + ' frames ' + pk.w + 'x' + pk.h);
                }
                catch (e) { log.warn('gif ' + name + ': ' + e); }
            } else if (name) log.warn('gif ' + name + ': gif_' + name + '.pack not found');
        };
        openPack(THEMES[themeId()].gif);
        settings.onChange((k) => { if (k === 'dashTheme') openPack(THEMES[themeId()].gif); });

        // All frames are baked when the pack opens or the display size changes, so there's never
        // a missing frame when RPM jumps. Takes ~2s for 16 frames at 300x300 on the emulator.
        const bakeAll = (Dw, Dh) => {
            const key = Dw + 'x' + Dh;
            if (!pk) return;
            if (layerKey !== key) {
                freeLayers();
                layerKey = key;
                layers = new Array(pk.n);
                const t0 = Date.now();
                for (let f = 0; f < pk.n; f++) layers[f] = bakeFrame(pk, f, Dw, Dh);
                log.info('gif ' + packName + ': baked ' + pk.n + ' frames at ' + Dw + 'x' + Dh + ' in ' + (Date.now() - t0) + ' ms');
            }
        };
        let curFrame = 0, lastTarget = -1, heldT = 0;
        const drawGif = (cv, gf, cx, cy, Dw, Dh) => {
            Dh = Dh || Dw;
            if (!pk) return;
            bakeAll(Dw, Dh);
            if (!layers) return;

            const n = pk.n;
            const target = gf * (n - 1) * 1.12;                                 // 1.12x -> frame n-1 at ~89% rpm
            curFrame += (target - curFrame) * 0.5;                              // 0.5 -> smoother tracking at high rpm

            // Smooth bob at stable RPM: continuous sine over all n frames
            heldT = Math.abs(target - lastTarget) < 0.12 ? heldT + 1 : 0;
            lastTarget = target;
            const bobOffset = (heldT > 3 && n > 2) ? Math.sin(Date.now() / 240) * 2.5 : 0;  // lower threshold: bob starts sooner

            const framePos = Math.max(0, Math.min(n - 1, curFrame + bobOffset));
            const fr = Math.round(framePos);                                      // nearest frame
            const x = Math.round(cx - Dw / 2), y = Math.round(cy - Dh / 2);
            const L = layers[fr];
            if (L) cv.blit(L, x, y);
        };

        /* ---------- warm-up ---------- */
        const safeRev = (oil) => {
            const red = redline(), cold = Math.min(coldRev(), red);
            if (!G.isNum(oil)) return cold;
            const w = Math.max(0, Math.min(1, (oil - 40) / (settings.get('warmOil') - 40)));
            return Math.round((cold + (red - cold) * w) / 50) * 50;
        };
        const tempInfo = (temp, target) => {
            if (!G.isNum(temp)) return { k: 'na', col: null, fill: 0 };
            if (temp >= target) return { k: 'ready', col: GREEN, fill: 1 };
            const fill = Math.max(0.04, Math.min(1, temp / target));       // one scale for cold and warm, so the bar never jumps at 25 deg
            if (temp < 25) return { k: 'cold', col: BLUE, fill };
            return { k: 'warm', col: null, fill };
        };

        /* ---------- tyres ---------- */
        const tyre = { p: [null, null, null, null], t: [null, null, null, null], tgt: [null, null, null, null] };

        // Same reading as apps/car_vitals (field-tested on cars): the TPMS sends named fields per
        // corner. Pressure is 0.1 x raw in the car's own pressure unit (bar / kPa / psi, from
        // Vehicle.statusNewCurrentUnitsStatusExt), temperature is degrees + 40 in the car's unit
        // (deg F on a car set to Fahrenheit). Both are shown in bar / deg C.
        const rawLogged = {};
        const logRaw = (name, raw) => {                       // first few distinct raw values -> log, to calibrate on a car
            const key = JSON.stringify(raw), l = rawLogged[name] || (rawLogged[name] = []);
            if (l.length >= 12 || l.indexOf(key) >= 0) return;
            l.push(key); log.info('raw ' + name + ': ' + key);
        };
        const carUnits = { press: null, temp: null, psiSeen: false };
        const PRESS_UNITS = { 1: 'BAR', 2: 'KPA', 3: 'PSI' }, TEMP_UNITS = { 1: 'C', 2: 'F' };
        const PRESS_TO_BAR = { BAR: 1, KPA: 0.01, PSI: 1 / 14.5038 };
        const unitName = (map, v) => (map[v] || (Object.values(map).indexOf(v) >= 0 ? v : null));
        const tyreP = (raw) => {
            if (!G.isNum(raw) || raw >= 65532) return null;
            const v = raw * 0.1, k = PRESS_TO_BAR[carUnits.press];
            let bar;
            if (k) bar = v * k;                                                   // the car's unit is known
            else if (v >= 0.5 && v <= 6) bar = v;                                 // not yet: each unit's plausible tyre pressures lie apart
            else if (v >= 7 && v < 60) { carUnits.psiSeen = true; bar = v / 14.5038; }
            else if (v >= 60 && v <= 600) bar = v / 100;
            else bar = v;
            return bar >= 0.5 && bar <= 6 ? bar : null;
        };
        const tyreT = (raw) => {
            if (!G.isNum(raw) || raw === 65535) return null;
            const v = raw - 40, f = carUnits.temp ? carUnits.temp === 'F' : carUnits.psiSeen, c = f ? (v - 32) * 5 / 9 : v;
            return c >= -40 && c <= 150 ? c : null;
        };
        const four = (v, a, b, c, d) => [v && v[a], v && v[b], v && v[c], v && v[d]];
        const watchTyres = () => {
            const done = (name) => (s) => { if (s && s.error) log.warn(name + ' unavailable: ' + s.error); return s; };
            ctx.signals.watch('de.bmw.infotainment.vehicle.Vehicle', '1', {
                statusNewCurrentUnitsStatusExt: (v) => {
                    const press = unitName(PRESS_UNITS, v && v.unitOfMeasurementAirPressure), temp = unitName(TEMP_UNITS, v && v.unitOfMeasurementTemperature);
                    if (press === carUnits.press && temp === carUnits.temp) return;
                    carUnits.press = press; carUnits.temp = temp;
                    log.info('car units: pressure ' + (press || '?') + ', temperature ' + (temp || '?'));
                },
            }, log).then(done('car units'), (e) => log.warn('car units: ' + e));
            // also read every 10 s: BMW's own x_call only ever reads the tyres, so a car may not notify them
            ctx.signals.watch('de.bmw.infotainment.vehicle.TPMS', '1', {
                statusTyrePressure: (v) => {
                    const r = four(v, 'actualValuePressureTyreFLH', 'actualValuePressureTyreFRH', 'actualValuePressureTyreRLH', 'actualValuePressureTyreRRH');
                    logRaw('tyre pressure', r);
                    if (v && v.actualValuePressureTyreFLH === undefined) logRaw('tyre pressure fields', Object.keys(v));
                    tyre.p = r.map(tyreP);
                },
                statusTyreTemperature: (v) => {
                    const r = four(v, 'actualValueTemperatureTyreFLH', 'actualValueTemperatureTyreFRH', 'actualValueTemperatureTyreRLH', 'actualValueTemperatureTyreRRH');
                    logRaw('tyre temperature', r);
                    tyre.t = r.map(tyreT);
                },
                statusTargetTyrePressure: (v) => {
                    const r = four(v, 'targetPressureTyreFLH', 'targetPressureTyreFRH', 'targetPressureTyreRLH', 'targetPressureTyreRRH');
                    logRaw('target tyre pressure', r);
                    tyre.tgt = r.map(tyreP);
                },
            }, log, { pollMs: 10000 }).then(done('TPMS'), (e) => log.warn('TPMS: ' + e));
        };
        try { watchTyres(); } catch (e) { log.warn('TPMS unavailable: ' + e); }

        /* ---------- boost: real from the FES sport display (bar = raw x 0.01, 255 = no value) ---------- */
        let realBoost = null;
        try {
            ctx.signals.watch('de.bmw.infotainment.drivingexcitement.FES', '1', {
                statusSwitchDriveDynamicSport2: (v) => { const r = v && v.displayBoostPressure; realBoost = (r == null || r === 255) ? null : Math.max(0, r * 0.01); },
            });
        } catch (e) { log.warn('boost signal unavailable: ' + e); }
        const boostNow = (demo, revFrac) => G.isNum(realBoost) ? realBoost : (demo ? Math.max(0, Math.min(1.5, (revFrac - 0.1) * 1.9)) : null);

        /* ---------- draw ---------- */
        ctx.loop('MAIN', 10, () => {
            const t = ctx.theme(), d = car.data();
            const cv = ctx.canvas(W, G.BOTTOM).clear(t.bg);
            // native chrome draws the real bar; we draw in the page area, which extends with cv.extra
            const sT = G.TOP, sB = G.pageBottom(cv), sL = 0, sR = W;
            G.frame(cv, t, ['Chidori'], 0, [d.demo && { text: 'DEMO' }]);

            if (d.demo) { tyre.p = [2.4, 2.4, 2.6, 2.2]; tyre.t = [74, 74, 81, 83]; tyre.tgt = [2.5, 2.5, 2.7, 2.7]; }

            const rpm = G.isNum(d.rpm) ? d.rpm : 0;
            const red = redline(), top = scaleMax(), N = Math.round(top / 1000);
            const revFrac = Math.max(0, Math.min(1, rpm / red));
            const shift = rpm >= red - 150;
            const frac = (r) => Math.max(0, Math.min(1, (r - 1000) / (top - 1000)));
            const gifFrac = Math.max(0, Math.min(1, (rpm - 1000) / (red - 1000)));

            if (themeId() === 'camgirl') {
                const boost = boostNow(d.demo, revFrac);
                drawCamgirl(cv, d, sT, sB, { rpm, red, top, N, gifFrac, boost, shift });
                return ui.image('MAIN_GFX', cv);
            }

            // dial centred between the left panels and the right readout grid
            const leftEdge = sL + GUT + PANEL_W, rightEdge = sR - GUT - RIGHT_W;
            const cTop = sT + VGUT, cBot = sB - VGUT;
            const CX = Math.round((leftEdge + rightEdge) / 2), CY = Math.round((cTop + cBot) / 2);
            const Rmax = Math.min((rightEdge - leftEdge) / 2, (cBot - cTop) / 2);
            const R = Math.floor(Rmax / 1.07) - 4;
            const aDeg = (f) => A_LO + f * A_SWEEP;
            const posAt = (f, r) => [CX + Math.sin(aDeg(f) * RAD) * r, CY - Math.cos(aDeg(f) * RAD) * r];

            const r1 = R, r0 = R - Math.round(R * 0.13);

            cv.arc(CX, CY, r0, r1, aDeg(0), aDeg(1), withAlpha(t.track, 0.85));
            cv.arc(CX, CY, r0, r1, aDeg(frac(red)), aDeg(1), withAlpha(SOLID.red, 0.30));
            if (rpm > 1000) cv.arc(CX, CY, r0, r1, aDeg(0), aDeg(frac(rpm)), shift ? SOLID.red : revColour(revFrac));

            const dsz = Math.round(R * 0.15);
            for (let k = 1; k <= N; k++) {
                const p = posAt((k - 1) / (N - 1), R + dsz);
                cv.text(String(k), p[0], p[1] + dsz * 0.36, dsz, k * 1000 >= red ? SOLID.red : t.text, { align: 'center', font: 'num' });
            }
            const rsz = Math.round(R * 0.30);
            cv.text(String(Math.round(rpm)), CX, CY + R * 0.78, rsz, shift ? SOLID.red : t.text, { align: 'center', font: 'num' });
            cv.text('RPM', CX, CY + R * 0.78 + rsz * 0.52, 18, t.dim, { align: 'center', font: 'label', spacing: 2 });
            // gear in the middle of the dial (P / R / N / D from the gearbox, else the engaged gear)
            const gsz = Math.round(R * 0.95), gBase = Math.round(CY + R * 0.04 + gsz * 0.345);   // glyph is ~0.69 em tall, centred a touch below the dial centre
            G.gear(cv, t, CX, gBase, { gear: d.gear, stage: d.stage, size: gsz, color: shift ? SOLID.red : null });
            if (shift) {                                           // SHIFT prompt sits above the gear, inside the ring
                const pw = Math.round(R * 0.8), ph = Math.round(R * 0.26), py = Math.round(CY - R * 0.64);
                cv.roundRect(CX - pw / 2, py, pw, ph, 8, withAlpha(SOLID.red, 0.92));
                cv.text('SHIFT', CX, py + ph * 0.74, Math.round(ph * 0.74), '#ffffff', { align: 'center', font: 'bold' });
            }

            // right column: SPEED big on top, BOOST | TORQUE below (the gear moved into the dial)
            const mph = settings.get('speedUnit') === 'mph';
            const spd = G.isNum(d.speed) ? Math.round(mph ? d.speed / MPH : d.speed) : 0;
            const boost = boostNow(d.demo, revFrac);
            const gX = sR - GUT - RIGHT_W, cxMid = gX + RIGHT_W / 2, cxA = gX + RIGHT_W * 0.27, cxB = gX + RIGHT_W * 0.73;
            const aHr = cBot - cTop, y1 = cTop + aHr * 0.16, y2 = cTop + aHr * 0.58, rszBig = 118, rsz2 = 78;
            G.readout(cv, t, cxMid, y1, { value: spd, label: 'SPEED', unit: mph ? 'mph' : 'km/h', size: rszBig, align: 'center' });
            if (G.isNum(boost)) G.readout(cv, t, cxA, y2, { value: boost, label: 'BOOST', unit: 'bar', size: rsz2, align: 'center', decimals: 1 });
            else G.readout(cv, t, cxA, y2, { text: '--', label: 'BOOST', unit: 'bar', size: rsz2, align: 'center' });
            G.readout(cv, t, cxB, y2, { value: d.torque, label: 'TORQUE', unit: 'Nm', size: rsz2, align: 'center', decimals: 0 });

            // left column: tyres + warm-up fill the content height
            const colH = cBot - cTop, tyH = Math.round((colH - GUT) * 0.46), wuH = colH - GUT - tyH;
            drawTyres(cv, t, sL + GUT, cTop, PANEL_W, tyH);
            drawWarmup(cv, t, sL + GUT, cTop + tyH + GUT, PANEL_W, wuH, d);
            return ui.image('MAIN_GFX', cv);
        });

        // ---- Cam Girl theme: a pink streaming-overlay layout (from the SimHub original) ----
        function drawCamgirl(cv, d, sT, sB, m) {
            const PINK = '#ff2e9a', PURPLE = '#9b30ff', LPINK = '#ff9ad4', WHITE = '#ffffff', BLK = '#000000', RED = '#e4002b';
            const TITLE = 'label', pad = 16, mph = settings.get('speedUnit') === 'mph';
            const box = (bx, by, bw, bh) => { cv.fillRect(bx - 5, by - 5, bw + 10, bh + 10, PINK); cv.fillRect(bx, by, bw, bh, BLK); };
            cv.fillRect(0, sT, W, sB - sT, BLK);

            // top: DONATIONS (= rpm, $ pink + white comma number) + ruler rev bar
            const topY = sT + 6;
            cv.text('DONATIONS', pad, topY + 40, 42, PINK, { font: TITLE, spacing: 1 });
            cv.text('$', pad, topY + 86, 40, PINK, { font: 'bold' });
            cv.text(Math.round(m.rpm).toLocaleString('en-US'), pad + 30, topY + 86, 40, WHITE, { font: 'num' });
            const barX0 = 372, barX1 = W - 150, barY = topY + 16, barH = 48, barW = barX1 - barX0;
            const fillF = Math.max(0, Math.min(1, m.rpm / m.top)), redF = m.red / m.top;
            const rf = redF > 0 ? Math.min(fillF, redF) / redF : fillF;                        // 0..1 up to redline
            const fillCol = rf < 0.45 ? LPINK : rf < 0.80 ? PURPLE : PINK;                     // light pink -> purple -> pink
            cv.fillRect(barX0, barY, barW, barH, '#1c1c1c');                                   // track
            cv.fillRect(barX0, barY, barW * Math.min(fillF, redF), barH, fillCol);
            if (rf >= 0.80 && Math.floor(Date.now() / 150) % 2) cv.fillRect(barX0, barY, barW * Math.min(fillF, redF), barH, withAlpha(WHITE, 0.32));
            if (fillF > redF) cv.fillRect(barX0 + barW * redF, barY, barW * (fillF - redF), barH, RED);
            const bo = 3;                                                                      // pink outline
            cv.fillRect(barX0 - bo, barY - bo, barW + 2 * bo, bo, PINK);
            cv.fillRect(barX0 - bo, barY + barH, barW + 2 * bo, bo, PINK);
            cv.fillRect(barX0 - bo, barY - bo, bo, barH + 2 * bo, PINK);
            cv.fillRect(barX0 + barW, barY - bo, bo, barH + 2 * bo, PINK);
            const fillEnd = barX0 + barW * Math.min(fillF, redF);
            for (let s = 0; s <= m.N * 2; s++) {                                               // ticks: dark on the pink fill, pink on the track
                const tx = barX0 + (barW * s) / (m.N * 2);
                cv.fillRect(tx - 1, barY, 3, s % 2 === 0 ? 16 : 9, tx <= fillEnd ? BLK : PINK);
            }
            for (let k = 0; k <= m.N; k++) cv.text(String(k), barX0 + (barW * k) / m.N, barY + barH + 28, 30, PINK, { align: 'center', font: 'num' });
            cv.text('x1000/$PM', barX1, barY + barH + 50, 16, PINK, { align: 'right', font: 'bold' });

            // left: landscape cam box (GIF fills it), then a roomier Gear box
            // the cam box takes what is left after a gear box of GEAR_H: its size follows the page height
            // (the car's full-screen layout is taller than the preview), keeping the GIF's 480:300 shape
            const GEAR_H = 72, camX = pad, camY = topY + 104;
            const camH = Math.max(120, Math.min(Math.round(540 * 300 / 480), Math.floor(sB - camY - 16 - GEAR_H - 6)));
            const camW = Math.min(540, Math.round(camH * 480 / 300));
            box(camX, camY, camW, camH);
            drawGif(cv, m.gifFrac, camX + camW / 2, camY + camH / 2, camW, camH);
            const gY = camY + camH + 16, gH = sB - gY - 6;
            box(camX, gY, camW, gH);
            cv.text('Gear', camX + 24, gY + gH / 2 + 8, 32, PINK, { font: TITLE });
            const gearTxt = G.isNum(d.gear) ? (d.gear > 0 ? String(d.gear) : d.gear === 0 ? 'N' : 'R') : '-';
            cv.text(gearTxt, camX + 190, gY + gH / 2 + 21, 54, WHITE, { font: 'num' });

            // right region: SPEED on top, then LIVE CHAT (left) + TYRES (right)
            const rX = camX + camW + 40;
            const spd = G.isNum(d.speed) ? Math.round(mph ? d.speed / MPH : d.speed) : 0;
            cv.text('SPEED:', rX + 6, camY + 40, 36, PINK, { font: TITLE });
            const sx = rX + 6 + cv.textWidth('SPEED:', 36, { font: TITLE }) + 18, sv = String(spd);
            cv.text(sv, sx, camY + 42, 46, WHITE, { font: 'num' });
            cv.text(mph ? 'mph' : 'km/h', sx + cv.textWidth(sv, 46, { font: 'num' }) + 10, camY + 42, 26, PINK, { font: 'bold' });

            const boxesY = camY + 74, boxesH = sB - boxesY - 6;
            const tyW = 332, tyX = W - pad - tyW, chW = tyX - 18 - rX;

            // LIVE CHAT: Torque, Boost, Oil Pressure, Oil Temp, Coolant, Safe rev limit (with units)
            box(rX, boxesY, chW, boxesH);
            cv.text('LIVE CHAT', rX + 20, boxesY + 44, 34, PINK, { font: TITLE });
            const oilP = d.demo ? (2 + m.gifFrac * 2).toFixed(1) : null, safe = safeRev(d.oil);
            const rows = [
                ['@torque', G.isNum(d.torque) ? Math.round(d.torque) + ' Nm' : ''],
                ['@boost', G.isNum(m.boost) ? m.boost.toFixed(1) + ' bar' : ''],
                ['@oil_p', oilP ? oilP + ' bar' : ''],
                ['@oil_t', G.isNum(d.oil) ? Math.round(d.oil) + ' °C' : ''],
                ['@water_t', G.isNum(d.coolant) ? Math.round(d.coolant) + ' °C' : ''],
                ['@safe_revs', safe + ' rpm'],
            ];
            // rows are spread from just under the title to just above the box's bottom edge
            const rowY0 = boxesY + 88, rowStep = (boxesH - 88 - 18) / (rows.length - 1);
            rows.forEach((r, i) => {
                const ry = rowY0 + i * rowStep;
                cv.text(r[0], rX + 24, ry, 26, PINK, { font: 'bold' });
                if (r[1]) cv.text(r[1], rX + chW - 24, ry, 26, WHITE, { align: 'right', font: 'num' });
            });

            // TYRES: narrower pink-themed 2x2 so the corners sit even
            box(tyX, boxesY, tyW, boxesH);
            cv.text('TYRES', tyX + 20, boxesY + 40, 32, PINK, { font: TITLE });
            const tp0 = boxesY + 62, tgH = (boxesH - 72) / 2, tgW = tyW / 2;
            for (let idx = 0; idx < 4; idx++) {
                const lab = ['FL', 'FR', 'RL', 'RR'][idx], ccx = tyX + (idx % 2) * tgW + tgW / 2, cyy = tp0 + (idx >> 1) * tgH;
                const p = tyre.p[idx], tpv = tyre.t[idx], tgt = tyre.tgt[idx];
                const low = G.isNum(p) && G.isNum(tgt) && p < tgt - 0.25;
                cv.text(lab, ccx, cyy + 28, 23, PINK, { align: 'center', font: 'bold' });   // bigger, centred in the cell
                const ps = G.isNum(p) ? p.toFixed(1) : '--';
                const pw = cv.textWidth(ps, 40, { font: 'num' }), bw = cv.textWidth(' bar', 18, {}), startX = ccx - (pw + bw) / 2;
                cv.text(ps, startX, cyy + 70, 40, low ? RED : WHITE, { font: 'num' });
                cv.text('bar', startX + pw + 7, cyy + 70, 18, PINK);
                if (G.isNum(tpv)) cv.text(Math.round(tpv) + '°C', ccx, cyy + 98, 20, PINK, { align: 'center', font: 'num' });
            }
        }

        function drawTyres(cv, t, x, y, w, h) {
            cv.roundRect(x, y, w, h, 10, withAlpha(t.panel || t.track, 0.9));
            cv.text('TYRES', x + 16, y + 28, 20, t.dim, { font: 'label' });
            const pad = 10, gTop = y + 42, gH = (y + h - pad) - gTop;
            const cw = (w - 3 * pad) / 2, chh = (gH - pad) / 2;
            const order = [[0, 'FL'], [1, 'FR'], [2, 'RL'], [3, 'RR']];
            for (let idx = 0; idx < 4; idx++) {
                const i = order[idx][0], lab = order[idx][1];
                const bx = x + pad + (idx % 2) * (cw + pad), by = gTop + (idx >> 1) * (chh + pad);
                const p = tyre.p[i], tp = tyre.t[i], tgt = tyre.tgt[i];
                const low = G.isNum(p) && G.isNum(tgt) && p < tgt - 0.25;
                const col = low ? SOLID.red : (G.isNum(p) && G.isNum(tgt) && Math.abs(p - tgt) <= 0.25) ? GREEN : t.text;
                cv.roundRect(bx, by, cw, chh, 8, withAlpha(t.track, 0.55));             // the box
                if (low) cv.roundRect(bx, by, cw, chh, 8, withAlpha(SOLID.red, 0.12));  // flag a low corner
                // top row: corner label left, temperature right. bottom row: pressure left, target right
                cv.text(lab, bx + 14, by + 20, 15, t.dim, { font: 'label' });
                if (G.isNum(tp)) cv.text(Math.round(tp) + '°C', bx + cw - 14, by + 20, 15, t.dim, { align: 'right' });
                const ps = G.isNum(p) ? p.toFixed(1) : '--', by2 = by + chh - 14;
                cv.text(ps, bx + 14, by2, 32, col, { font: 'num' });
                cv.text('bar', bx + 14 + cv.textWidth(ps, 32, { font: 'num' }) + 6, by2, 15, t.dim);
                if (G.isNum(tgt)) cv.text(tgt.toFixed(1), bx + cw - 14, by2, 18, t.dim, { align: 'right', font: 'num' });  // target bar
            }
        }

        function drawWarmup(cv, t, x, y, w, h, d) {
            const oilT = settings.get('warmOil'), coolT = settings.get('warmCoolant');
            const io = tempInfo(d.oil, oilT), ic = tempInfo(d.coolant, coolT);
            const anyCold = io.k === 'cold' || ic.k === 'cold', anyWarm = io.k === 'warm' || ic.k === 'warm';
            const head = anyCold ? 'COLD' : anyWarm ? 'WARMING UP' : 'UP TO TEMP';
            const headCol = anyCold ? BLUE : anyWarm ? (t.warn || t.accent) : GREEN;
            cv.roundRect(x, y, w, h, 10, withAlpha(t.panel || t.track, 0.9));
            cv.fillRect(x, y, w, 32, withAlpha(headCol, 0.25));
            cv.text(head, x + w / 2, y + 23, 20, headCol, { align: 'center', font: 'bold' });

            const avail = h - 32 - 48, rowH = avail / 2;
            const row = (ry, label, temp, target, info) => {
                const cy = ry + rowH / 2;
                cv.text(label, x + 18, cy - 8, 17, t.dim, { font: 'label' });
                cv.text('target ' + target + '°', x + 18, cy + 13, 14, t.dim);
                cv.text(G.isNum(temp) ? Math.round(temp) + '°C' : '--', x + w - 18, cy + 4, 32, info.col || t.text, { align: 'right', font: 'num' });
                const bx = x + 18, bw = w - 36, by = cy + 24, bh = 7;
                cv.roundRect(bx, by, bw, bh, 3, withAlpha(t.track, 0.8));
                if (info.fill > 0) cv.roundRect(bx, by, bw * info.fill, bh, 3, info.col || (t.warn || t.accent));
            };
            row(y + 32, 'OIL', d.oil, oilT, io);
            row(y + 32 + rowH, 'COOLANT', d.coolant, coolT, ic);

            const sr = safeRev(d.oil), red = redline(), sy = y + h - 42;
            cv.text('SAFE REV LIMIT', x + 18, sy + 14, 15, t.dim, { font: 'label' });
            cv.text(sr + ' rpm', x + w - 18, sy + 14, 18, t.text, { align: 'right', font: 'num' });
            cv.roundRect(x + 18, sy + 24, w - 36, 8, 4, withAlpha(t.track, 0.8));
            cv.roundRect(x + 18, sy + 24, (w - 36) * Math.min(1, sr / red), 8, 4, t.warn || t.accent);
        }
    },
});
